#ifndef UNCHANGEVALUE_H
#define UNCHANGEVALUE_H
class UnchangeValue{
    const int ELEVATOR_OUT_1 = 1258;
    const int ELEVATOR_OUT_2 = 1258+520;
    const int ELEVATOR_OUT_3 = 1258+520+903;
};
#endif // UNCHANGEVALUE_H
