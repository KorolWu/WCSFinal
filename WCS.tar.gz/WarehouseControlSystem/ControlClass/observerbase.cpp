#include "observerbase.h"

ObserverBase::ObserverBase()
{

}

void ObserverBase::updateStatusOnBase()
{
    qDebug()<<"base observer";
}
